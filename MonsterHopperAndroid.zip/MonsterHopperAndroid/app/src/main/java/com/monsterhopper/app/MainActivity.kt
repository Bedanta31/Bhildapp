package com.monsterhopper.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        val root = LinearLayout(this).apply { orientation = 1; gravity = Gravity.CENTER_HORIZONTAL; setPadding(32, 40, 32, 24); setBackgroundColor(Color.rgb(9,6,16)) }
        fun text(s: String, size: Float, color: Int) = TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(0,12,0,12) }
        root.addView(text("MONSTER HOPPER", 26f, Color.rgb(192,132,252)))
        root.addView(text("ROBLOX SERVER TOOLS • ANDROID", 12f, Color.LTGRAY))
        status = text("Status: stopped\\nPlace ID: ${ServerRepository.PLACE_ID}", 14f, Color.WHITE)
        root.addView(status)
        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply { text=label; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(88,28,135)); setOnClickListener { action() } })
        }
        button("ENABLE FLOATING BUBBLE") {
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else { startService(Intent(this, OverlayService::class.java)); status.text="Bubble enabled" }
        }
        button("START AUTO-HOP") {
            if (!Settings.canDrawOverlays(this)) {
                status.text="Allow Display over other apps first"
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val i=Intent(this, HopService::class.java).setAction(HopService.START)
                if (Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
                startService(Intent(this, OverlayService::class.java)); status.text="Auto-Hop started; see notification"
            }
        }
        button("STOP AUTO-HOP") { startService(Intent(this, HopService::class.java).setAction(HopService.STOP)); status.text="Stop requested" }
        button("CHECK SERVER API") {
            Thread { val r=ServerRepository.fetch(true); runOnUiThread { status.text="Servers: ${r.servers.size}\\nSource: ${r.source}\\n${r.message}" } }.start()
        }
        root.addView(text("NOTE: Android or Roblox may show a launch confirmation or block background launches. Launch requested does not mean joined.", 12f, Color.LTGRAY))
        setContentView(root)
    }
}
