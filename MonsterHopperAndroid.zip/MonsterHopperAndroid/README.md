# Monster Hopper Android

Native Kotlin Android Studio starter project for Place ID `98664161516921`.

## Build
1. Install Android Studio on a PC.
2. Open this project folder and allow Gradle sync (JDK 17, Android SDK 35).
3. Run on a connected Android phone, or choose Build → Build Bundle(s) / APK(s) → Build APK(s).
4. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

## First run
Grant Notifications permission and Display over other apps permission. Start Auto-Hop from the app. Keep the foreground notification visible. If your phone offers an Unrestricted battery option, enable it for testing.

## Important limitations
The service is user-started and foreground, but Android/OEM power management can still stop it. Roblox or Android can block or ask for confirmation on repeated external app launches. A launch request is not proof of a successful join. This app does not attempt to bypass Android restrictions, simulate taps, or use Accessibility automation. Roblox public server API behavior and rate limits may change.
