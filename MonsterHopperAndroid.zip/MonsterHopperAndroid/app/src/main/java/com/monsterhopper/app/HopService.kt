package com.monsterhopper.app

import android.app.*
import android.content.Intent
import android.net.Uri
import android.os.*
import android.util.Log

class HopService : Service() {
    companion object {
        const val START = "hopper.START"; const val STOP = "hopper.STOP"; const val NOW = "hopper.NOW"
        const val CHANNEL = "hopper_status"; const val ID = 4102
    }
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var busy = false
    private var currentId: String? = null
    private var retry = 5000L
    private val interval = 45000L

    override fun onCreate() { super.onCreate(); channel() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            STOP -> { stopLoop(); stopSelf(); return START_NOT_STICKY }
            NOW -> { if (running) schedule(0) }
            else -> if (!running) {
                running = true
                startForeground(ID, notification("Starting server discovery"))
                schedule(1000)
            }
        }
        return START_STICKY
    }
    private fun schedule(ms: Long) { handler.removeCallbacks(loop); if (running) handler.postDelayed(loop, ms) }
    private val loop = Runnable {
        if (!running || busy) return@Runnable
        busy = true
        Thread {
            val result = ServerRepository.fetch()
            val chosen = ServerRepository.choose(result.servers, currentId)
            handler.post {
                busy = false
                if (!running) return@post
                if (chosen == null) {
                    update("No servers (${result.source}) • retrying")
                    retry = (retry * 2).coerceAtMost(60000L)
                    schedule(retry)
                } else {
                    retry = 5000L; currentId = chosen.id
                    launch(chosen.id)
                    schedule(interval)
                }
            }
        }.start()
    }
    private fun launch(id: String) {
        try {
            val uri = Uri.parse("roblox://experiences/start?placeId=${ServerRepository.PLACE_ID}&gameInstanceId=$id")
            startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            update("Launch requested • join unverified")
        } catch (e: Exception) {
            Log.w("MonsterHopper", "Roblox launch failed", e)
            update("Launch blocked • tap Hop now")
        }
    }
    private fun stopLoop() { running=false; handler.removeCallbacksAndMessages(null); stopForeground(STOP_FOREGROUND_REMOVE) }
    private fun channel() {
        if (Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Monster Hopper", NotificationManager.IMPORTANCE_LOW))
    }
    private fun notification(msg: String): Notification {
        val open=PendingIntent.getActivity(this,1,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or immutable())
        val now=PendingIntent.getService(this,2,Intent(this,HopService::class.java).setAction(NOW),PendingIntent.FLAG_UPDATE_CURRENT or immutable())
        val stop=PendingIntent.getService(this,3,Intent(this,HopService::class.java).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT or immutable())
        val b=if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,CHANNEL) else Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Monster Hopper").setContentText(msg)
            .setContentIntent(open).setOngoing(running)
            .addAction(android.R.drawable.ic_media_play,"Hop now",now)
            .addAction(android.R.drawable.ic_delete,"Stop",stop).build()
    }
    private fun update(msg: String) { getSystemService(NotificationManager::class.java).notify(ID,notification(msg)) }
    private fun immutable() = if(Build.VERSION.SDK_INT>=23) PendingIntent.FLAG_IMMUTABLE else 0
    override fun onDestroy() { stopLoop(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
