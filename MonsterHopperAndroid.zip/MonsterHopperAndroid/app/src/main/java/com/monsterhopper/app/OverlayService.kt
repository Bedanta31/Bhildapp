package com.monsterhopper.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var open = false
    private var bubbleParams: WindowManager.LayoutParams? = null
    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p=WindowManager.LayoutParams(dp(58),dp(58),type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=dp(14); y=dp(180) }
        val b=TextView(this).apply {
            text="MH"; textSize=15f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setTextColor(Color.WHITE)
            background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(192,132,252),Color.rgb(88,28,135))).apply { shape=GradientDrawable.OVAL; setStroke(dp(2),Color.rgb(233,213,255)) }
        }
        var sx=0f; var sy=0f; var px=0; var py=0
        b.setOnTouchListener { _, e -> when(e.action) {
            MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; px=p.x; py=p.y; true }
            MotionEvent.ACTION_MOVE -> { p.x=px+(e.rawX-sx).toInt(); p.y=py+(e.rawY-sy).toInt(); wm.updateViewLayout(b,p); true }
            MotionEvent.ACTION_UP -> { if(kotlin.math.abs(e.rawX-sx)<dp(8)&&kotlin.math.abs(e.rawY-sy)<dp(8)) toggle(); true }
            else -> true
        } }
        wm.addView(b,p); bubble=b; bubbleParams=p
    }
    private fun toggle() {
        if(open) { panel?.let { try { wm.removeView(it) } catch (_:Exception){} }; panel=null; open=false; return }
        val box=LinearLayout(this).apply { orientation=1; setPadding(dp(10),dp(10),dp(10),dp(10)); background=GradientDrawable().apply { setColor(Color.rgb(18,10,29)); cornerRadius=dp(16).toFloat(); setStroke(dp(1),Color.rgb(192,132,252)) } }
        fun add(label:String, action:()->Unit) {
            box.addView(TextView(this).apply {
                text=label; textSize=13f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(8),dp(12),dp(8),dp(12)); setBackgroundColor(Color.rgb(52,26,78))
                setOnClickListener { action(); toggle() }
            },LinearLayout.LayoutParams(dp(190),dp(46)).apply { bottomMargin=dp(6) })
        }
        add("▶ START AUTO-HOP") { val i=Intent(this,HopService::class.java).setAction(HopService.START); if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i) }
        add("↻ HOP NOW") { startService(Intent(this,HopService::class.java).setAction(HopService.NOW)) }
        add("■ STOP AUTO-HOP") { startService(Intent(this,HopService::class.java).setAction(HopService.STOP)) }
        add("× CLOSE") {}
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p=WindowManager.LayoutParams(dp(210),-2,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=bubbleParams?.x?:dp(14); y=(bubbleParams?.y?:dp(180))+dp(64) }
        wm.addView(box,p); panel=box; open=true
    }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    override fun onDestroy() { bubble?.let { try{wm.removeView(it)}catch(_:Exception){} }; panel?.let{try{wm.removeView(it)}catch(_:Exception){}}; super.onDestroy() }
    override fun onBind(intent:Intent?):IBinder?=null
}
