package com.monsterhopper.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class PublicServer(val id: String, val playing: Int, val maxPlayers: Int)
data class FetchResult(val servers: List<PublicServer>, val source: String, val message: String)

object ServerRepository {
    const val PLACE_ID = "98664161516921"
    private const val TTL = 90_000L
    private val lock = Any()
    private var cache: List<PublicServer> = emptyList()
    private var cacheAt = 0L

    fun fetch(force: Boolean = false): FetchResult {
        synchronized(lock) {
            if (!force && cache.isNotEmpty() && System.currentTimeMillis() - cacheAt < TTL)
                return FetchResult(cache, "cache", "Using recent cache")
        }
        try {
            val found = LinkedHashMap<String, PublicServer>()
            var cursor: String? = null
            repeat(3) {
                var url = "https://games.roblox.com/v1/games/$PLACE_ID/servers/Public?sortOrder=Asc&limit=100"
                if (!cursor.isNullOrBlank()) url += "&cursor=" + URLEncoder.encode(cursor, "UTF-8")
                val c = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000; readTimeout = 12000
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "MonsterHopperAndroid/1.0")
                }
                val code = c.responseCode
                if (code == 429) throw IllegalStateException("Roblox rate limit (HTTP 429)")
                if (code !in 200..299) throw IllegalStateException("Roblox API HTTP $code")
                val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                c.disconnect()
                val data = json.optJSONArray("data")
                if (data != null) for (i in 0 until data.length()) {
                    val o = data.optJSONObject(i) ?: continue
                    val id = o.optString("id")
                    if (id.isNotBlank()) found[id] = PublicServer(id, o.optInt("playing"), o.optInt("maxPlayers"))
                }
                cursor = json.optString("nextPageCursor").takeIf { it.isNotBlank() && it != "null" }
                if (cursor == null || data == null || data.length() == 0) return@repeat
            }
            if (found.isNotEmpty()) synchronized(lock) { cache = found.values.toList(); cacheAt = System.currentTimeMillis() }
            synchronized(lock) {
                if (found.isNotEmpty()) return FetchResult(cache, "fresh", "Fetched ${cache.size} servers")
                if (cache.isNotEmpty()) return FetchResult(cache, "stale-cache", "Empty API result; retained previous cache")
            }
            return FetchResult(emptyList(), "empty", "API returned no public servers")
        } catch (e: Exception) {
            synchronized(lock) {
                if (cache.isNotEmpty()) return FetchResult(cache, "stale-cache", "${e.message}; using ${cache.size} cached servers")
            }
            return FetchResult(emptyList(), "error", e.message ?: "Network error")
        }
    }

    fun choose(servers: List<PublicServer>, current: String?): PublicServer? {
        val pool = servers.filter { it.id != current && it.playing < it.maxPlayers }
            .ifEmpty { servers.filter { it.id != current } }
        return pool.randomOrNull()
    }
}
